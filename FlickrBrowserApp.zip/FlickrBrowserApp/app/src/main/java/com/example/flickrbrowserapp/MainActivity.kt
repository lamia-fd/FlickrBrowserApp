package com.example.flickrbrowserapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.coroutines.*
import org.json.JSONObject
import java.lang.Exception
import java.net.URL
data class flickrImg(var title: String, var link: String)
class MainActivity : AppCompatActivity() {

    val key="a1b9e81cf48b6b0a82851b33ccb2622e"
    private lateinit var images: ArrayList<flickrImg>

    private lateinit var rv: RecyclerView
    private lateinit var rvAdapter: recycler
    private lateinit var searchLayout: LinearLayout
    private lateinit var editText: EditText
    private lateinit var but: Button

    private lateinit var imageView: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        images = arrayListOf()
        editText=findViewById(R.id.editText)
        imageView=findViewById(R.id.imageView)
        but=findViewById(R.id.button)
        searchLayout=findViewById(R.id.searchLayout)
        rv = findViewById(R.id.recyclerView)
        rvAdapter = recycler(this,images)
        rv.adapter = rvAdapter
        rv.layoutManager = LinearLayoutManager(this)


        var imageView=findViewById<ImageView>(R.id.imageView)

        but.setOnClickListener {
            if(editText.text.isNotEmpty()){
                requestApi()
            }else{
                Toast.makeText(this, "Search field is empty", Toast.LENGTH_LONG).show()
            }
        }


        imageView.setOnClickListener { closeImg() }

       }



    private fun requestApi()
    {

        CoroutineScope(Dispatchers.IO).launch {

                val data = async {

                    fetchRandomAdvice()

                }.await()

                if (data.isNotEmpty())
                {

                    updateAdviceText(data)}


            }

    }

    private fun fetchRandomAdvice():String{

        var response=""
        try {
            response = URL("https://api.flickr.com/services/rest/?method=flickr.photos.search&per_page=10&api_key=cb0cbca5c50568f7e3189b08d8e6a89b&tags=${editText.text}&format=json&nojsoncallback=1").readText(Charsets.UTF_8)

        }catch (e: Exception)
        {
            println("Error $e")

        }
        return response

    }

    private suspend fun updateAdviceText(data:String)
    {
        withContext(Dispatchers.Main)
        {

            val jsonObject = JSONObject(data)
            val photos = jsonObject.getJSONObject("photos").getJSONArray("photo")
            for(i in 0 until photos.length()){
                val title = photos.getJSONObject(i).getString("title")
                val farmID = photos.getJSONObject(i).getString("farm")
                val serverID = photos.getJSONObject(i).getString("server")
                val id = photos.getJSONObject(i).getString("id")
                val secret = photos.getJSONObject(i).getString("secret")
                val photoLink = "https://farm$farmID.staticflickr.com/$serverID/${id}_$secret.jpg"
                images.add(flickrImg(title,photoLink))


            }
            rvAdapter.notifyDataSetChanged()




        }

    }

    fun openImg(link: String){
        Glide.with(this).load(link).into(imageView)
        imageView.isVisible = true
        rv.isVisible = false
        searchLayout.isVisible = false
    }

    private fun closeImg(){
        imageView.isVisible = false
        rv.isVisible = true
        searchLayout.isVisible = true
        images.clear()
        rvAdapter.notifyDataSetChanged()

    }
}


