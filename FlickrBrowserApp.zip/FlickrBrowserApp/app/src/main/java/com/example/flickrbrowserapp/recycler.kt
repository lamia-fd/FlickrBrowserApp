package com.example.flickrbrowserapp

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import kotlinx.android.synthetic.main.image.view.*

class recycler(val activity: MainActivity,private val flickrInput: ArrayList<flickrImg>): RecyclerView.Adapter<recycler.ItemHolder>() {
    class ItemHolder(itemView: View) : RecyclerView.ViewHolder(itemView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHolder {
        return ItemHolder(LayoutInflater.from(parent.context).inflate(R.layout.image, parent, false))
    }

    override fun onBindViewHolder(holder: ItemHolder, position: Int) {

        val flickr=flickrInput[position]
        holder.itemView.apply {
           tv.text=flickr.title
            Glide.with( activity)
             .load(flickr.link).into(imageView)
            imageLayout.setOnClickListener {
                activity.openImg(flickr.link)
            }

    }}

    override fun getItemCount()= flickrInput.count()
//fun bind(userInput:String){
    //  itemView.tvUserInput
//}
}